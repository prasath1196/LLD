#!/bin/bash

bundle install
ruby -W0 geektrust.rb sample_input/input1.txt